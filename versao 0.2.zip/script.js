// =====================================================
// SIMULAÇÃO DO BANCO DE DADOS (Depois será o Supabase)
// =====================================================
let empresas = [
    { id: 1, nomeFantasia: "14 BEER BEBIDAS LTDA", razaoSocial: "14 Beer Bebidas LTDA", cnpj: "11.111.111/0001-11", regime: "Simples Nacional", observacao: "" },
    { id: 2, nomeFantasia: "A B CONSULTORIA", razaoSocial: "A B Consultoria em Ergonomia LTDA", cnpj: "22.222.222/0001-22", regime: "Simples Nacional", observacao: "" },
    { id: 3, nomeFantasia: "ALTO CONSULTORIA", razaoSocial: "Alto Consultoria e Inovação em Software", cnpj: "33.333.333/0001-33", regime: "Lucro Presumido", observacao: "" },
    { id: 4, nomeFantasia: "ANDERSON CAVALCANTE", razaoSocial: "Anderson Cavalcante da Silva", cnpj: "44.444.444/0001-44", regime: "Simples Nacional", observacao: "" },
    { id: 5, nomeFantasia: "ANTONIO CARLOS", razaoSocial: "Antonio Carlos Alves Borges", cnpj: "55.555.555/0001-55", regime: "Lucro Real", observacao: "" },
    // ... adicione mais para testar a paginação
];

// Variáveis de controle
let paginaAtual = 1;
const itensPorPagina = 10;
let termoBusca = "";
let filtroRegime = "";
let idEditando = null;

// =====================================================
// NAVEGAÇÃO ENTRE TELAS
// =====================================================
function abrirFormulario(id = null) {
    document.getElementById('tela-lista').classList.add('escondido');
    document.getElementById('tela-formulario').classList.remove('escondido');
    document.getElementById('form-empresa').reset();
    idEditando = id;

    if (id) {
        document.getElementById('titulo-formulario').textContent = "Editar Empresa";
        const empresa = empresas.find(e => e.id === id);
        if (empresa) {
            document.getElementById('empresa-id').value = empresa.id;
            document.getElementById('nome-fantasia').value = empresa.nomeFantasia;
            document.getElementById('razao-social').value = empresa.razaoSocial;
            document.getElementById('cnpj').value = empresa.cnpj;
            document.getElementById('regime').value = empresa.regime;
            document.getElementById('observacao').value = empresa.observacao;
        }
    } else {
        document.getElementById('titulo-formulario').textContent = "Nova Empresa";
        document.getElementById('empresa-id').value = "";
    }
}

function voltarParaLista() {
    document.getElementById('tela-formulario').classList.add('escondido');
    document.getElementById('tela-lista').classList.remove('escondido');
    renderizarLista();
}

// =====================================================
// CRUD - SALVAR (CREATE / UPDATE)
// =====================================================
function salvarEmpresa(event) {
    event.preventDefault();

    const dados = {
        nomeFantasia: document.getElementById('nome-fantasia').value,
        razaoSocial: document.getElementById('razao-social').value,
        cnpj: document.getElementById('cnpj').value,
        regime: document.getElementById('regime').value,
        observacao: document.getElementById('observacao').value,
    };

    if (idEditando) {
        // UPDATE
        const index = empresas.findIndex(e => e.id === idEditando);
        empresas[index] = { ...empresas[index], ...dados };
        alert("Empresa atualizada com sucesso!");
    } else {
        // CREATE
        const novoId = empresas.length > 0 ? Math.max(...empresas.map(e => e.id)) + 1 : 1;
        empresas.push({ id: novoId, ...dados });
        alert("Empresa cadastrada com sucesso!");
    }

    voltarParaLista();
}

// =====================================================
// CRUD - DELETAR (DELETE)
// =====================================================
function deletarEmpresa(id) {
    if (!confirm("Tem certeza que deseja excluir esta empresa?")) return;
    empresas = empresas.filter(e => e.id !== id);
    renderizarLista();
}

// =====================================================
// FILTROS E BUSCA
// =====================================================
function filtrarEmpresas() {
    termoBusca = document.getElementById('input-busca').value.toLowerCase();
    filtroRegime = document.getElementById('filtro-regime').value;
    paginaAtual = 1; // Reseta para a primeira página ao filtrar
    renderizarLista();
}

function obterEmpresasFiltradas() {
    return empresas.filter(e => {
        const matchBusca = e.nomeFantasia.toLowerCase().includes(termoBusca) ||
                           e.razaoSocial.toLowerCase().includes(termoBusca);
        const matchRegime = filtroRegime === "" || e.regime === filtroRegime;
        return matchBusca && matchRegime;
    });
}

// =====================================================
// RENDERIZAÇÃO DA LISTA E PAGINAÇÃO
// =====================================================
function renderizarLista() {
    const listaFiltrada = obterEmpresasFiltradas();
    const totalPaginas = Math.ceil(listaFiltrada.length / itensPorPagina);
    
    // Ajusta a página atual se ela for maior que o total
    if (paginaAtual > totalPaginas && totalPaginas > 0) paginaAtual = totalPaginas;

    const inicio = (paginaAtual - 1) * itensPorPagina;
    const fim = inicio + itensPorPagina;
    const itensPagina = listaFiltrada.slice(inicio, fim);

    const corpoTabela = document.getElementById('corpo-tabela');
    corpoTabela.innerHTML = "";

    if (itensPagina.length === 0) {
        corpoTabela.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 20px;">Nenhuma empresa encontrada.</td></tr>`;
    } else {
        itensPagina.forEach((empresa, index) => {
            const numeroLinha = inicio + index + 1;
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${numeroLinha}</td>
                <td>${empresa.nomeFantasia}</td>
                <td>${empresa.razaoSocial}</td>
                <td>${empresa.cnpj || '-'}</td>
                <td>${empresa.regime}</td>
                <td>
                    <button class="btn btn-secondary btn-sm" onclick="abrirFormulario(${empresa.id})">✏️ Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="deletarEmpresa(${empresa.id})">🗑️ Excluir</button>
                </td>
            `;
            corpoTabela.appendChild(tr);
        });
    }

    renderizarPaginacao(totalPaginas);
}

function renderizarPaginacao(totalPaginas) {
    const container = document.getElementById('paginacao');
    container.innerHTML = "";

    if (totalPaginas <= 1) return;

    // Botão Anterior
    const btnAnterior = document.createElement('button');
    btnAnterior.textContent = "← Anterior";
    btnAnterior.disabled = paginaAtual === 1;
    btnAnterior.onclick = () => { paginaAtual--; renderizarLista(); };
    container.appendChild(btnAnterior);

    // Botões Numéricos
    for (let i = 1; i <= totalPaginas; i++) {
        const btn = document.createElement('button');
        btn.textContent = i;
        if (i === paginaAtual) btn.classList.add('ativo');
        btn.onclick = () => { paginaAtual = i; renderizarLista(); };
        container.appendChild(btn);
    }

    // Botão Próximo
    const btnProximo = document.createElement('button');
    btnProximo.textContent = "Próximo →";
    btnProximo.disabled = paginaAtual === totalPaginas;
    btnProximo.onclick = () => { paginaAtual++; renderizarLista(); };
    container.appendChild(btnProximo);
}

// =====================================================
// UPLOAD E DOWNLOAD (CSV)
// =====================================================
function baixarModelo() {
    // Cria um CSV de exemplo para o usuário preencher
    const cabecalho = "Nome Fantasia;Razao Social;CNPJ;Regime;Observacao\n";
    const exemplo = "Empresa Exemplo;Empresa Exemplo LTDA;00.000.000/0001-00;Simples Nacional;Nenhuma\n";
    const csvContent = cabecalho + exemplo;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "modelo_empresas.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function importarCSV(event) {
    const arquivo = event.target.files[0];
    if (!arquivo) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const texto = e.target.result;
        const linhas = texto.split('\n').filter(l => l.trim() !== '');
        
        // Pula o cabeçalho (linha 0)
        let importados = 0;
        for (let i = 1; i < linhas.length; i++) {
            const colunas = linhas[i].split(';');
            if (colunas.length >= 4) {
                const novoId = empresas.length > 0 ? Math.max(...empresas.map(e => e.id)) + 1 : 1;
                empresas.push({
                    id: novoId,
                    nomeFantasia: colunas[0]?.trim() || '',
                    razaoSocial: colunas[1]?.trim() || '',
                    cnpj: colunas[2]?.trim() || '',
                    regime: colunas[3]?.trim() || 'Simples Nacional',
                    observacao: colunas[4]?.trim() || ''
                });
                importados++;
            }
        }
        alert(`${importados} empresas importadas com sucesso!`);
        renderizarLista();
        event.target.value = ""; // Limpa o input
    };
    reader.readAsText(arquivo);
}

// =====================================================
// INICIALIZAÇÃO
// =====================================================
document.addEventListener('DOMContentLoaded', () => {
    renderizarLista();
});